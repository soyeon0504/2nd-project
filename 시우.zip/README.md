# 2차 프로젝트

- 컴포넌트 네이밍 (Component Naming):
  항상 파스칼 케이스사용 (예 : Header.js)

- 스타일드 컴포넌트 (styled-components) - emotion
  스타일 컴포넌트는 일반 컴포넌트와 구별을 위해 Styled라는 접두사를 추가
  (예 : StyledHeader)
