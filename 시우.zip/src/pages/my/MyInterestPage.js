import React from "react";
import MyInterestList from "../../components/my/interest/MyInterestList";


const MyInterestPage = () => {

  return (
    <>
      <MyInterestList />
    </>
  );
};

export default MyInterestPage;
