import React from "react";
import Layout from "../../layouts/Layout";
const MyPage = () => {
  return (
    <Layout>
      <div>MyPage</div>;
    </Layout>
  );
};

export default MyPage;
