import React, { useState } from "react";
import { Upload } from "antd";
import ImgCrop from "antd-img-crop";
import "../../styles/imageUpload.css";

const ImageUpload = () => {
  //기본 값이 변경될떄마다
  const [fileList, setFileList] = useState([
    {
      uid: "-1",
      name: "image.png",
      status: "done",
      url: "",
    },
  ]);

  const onChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };
  const onPreview = async file => {
    let src = file.url;
    if (!src) {
      src = await new Promise(resolve => {
        const reader = new FileReader();
        reader.readAsDataURL(file.originFileObj);
        reader.onload = () => resolve(reader.result);
      });
    }
    const image = new Image();
    image.src = src;
    const imgWindow = window.open(src);
    imgWindow?.document.write(image.outerHTML);
  };
  return (
    <ImgCrop rotationSlider>
      <Upload
        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
        listType="picture-card"
        fileList={fileList}
        onChange={onChange}
        onPreview={onPreview}
        style={{ display: "flex", width: "966px", height: "200px" }}
      >
        {fileList.length < 10 && "+ Upload"}
      </Upload>
    </ImgCrop>
  );
};
export default ImageUpload;
