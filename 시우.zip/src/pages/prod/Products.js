import React, { useState } from "react";

const Products = () => {
  //리스트 아이탬 state
  const [listItems, setListItems] = useState([]);

  //버튼 클릭시 함수 호출
  const handleButtonClick = () => {
    const newIem = `아이템 ${listItems.length + 1}`;
    const newList = [...listItems, newIem];

    // 상태 업데이트
    setListItems(newList);
  };
  return (
    <div>
      <form>
        <label htmlFor="picture">
          <p>사진</p> <p>*</p> <p>0/10</p>
        </label>
        <input type="text" name="picture" id="picture" />

        <ladel htmlFor="jepum">
          <p>상품명</p> <p>*</p>
        </ladel>
        <input type="text" name="jepum" id="jepum" />

        <div>
          <button onClick={handleButtonClick}>스마트기기</button>
          <button>pc/노트북</button>
          <button>영상카메라</button>
          <button>음향</button>
          <button>게임 기기</button>
        </div>

        <div>
          <ul>
            {listItems.map((item, index) => (
              <li key={index}>{item}</li>
            ))}

            <li>스마트워치</li>
            <li>태블릿</li>
            <li>겔럭시</li>
            <li>아이폰</li>
          </ul>
        </div>
        <div>
          <ul>
            <li>노트북</li>
            <li>pc</li>
            <li>마우스</li>
            <li>킵모드</li>
          </ul>
        </div>
      </form>
    </div>
  );
};

export default Products;
