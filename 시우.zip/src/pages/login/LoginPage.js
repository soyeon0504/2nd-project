import React from "react";
import Layout from "../../layouts/Layout";
const LoginPage = () => {
  return (
    <Layout>
      <div>LoginPage</div>;
    </Layout>
  );
};

export default LoginPage;
