import React from "react";
import Layout from "../../layouts/Layout";

const JoinPage = () => {
  return (
    <Layout>
      <h1>JoinPage</h1>
    </Layout>
  );
};

export default JoinPage;
