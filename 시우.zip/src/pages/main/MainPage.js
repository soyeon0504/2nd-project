import React from "react";
import Layout from "../../layouts/Layout";

const MainPage = () => {
  return (
    <Layout>
      <h1>MainPage</h1>
    </Layout>
  );
};

export default MainPage;
