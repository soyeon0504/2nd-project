import React from "react";
import Layout from "../../layouts/Layout";
const PayPage = () => {
  return (
    <Layout>
      <div>PayPage</div>;
    </Layout>
  );
};

export default PayPage;
