import React from 'react'
import CustomList from '../../components/customer/CustomList'

export const CustomerFAQPage = () => {
  return (
    <>
        <CustomList />
    </>
  )
}
