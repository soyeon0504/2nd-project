export const Common = {
  // 숫자가 높을수록 밝은 색
  color: {
    primary: "#2C39B5",
    p100: "#000000",
    p200: "#4B4B4B",
    p300: "#777777",
    p400: "#E4E7FF",
    p500: "#F2F2FF",
    p600: "#FFFFFF",
  },
};
