import React from "react";
import Layout from "../../layouts/Layout";

const AddEditPage = () => {
  return (
    <Layout>
      <h1>AddEdit</h1>
    </Layout>
  );
};

export default AddEditPage;
